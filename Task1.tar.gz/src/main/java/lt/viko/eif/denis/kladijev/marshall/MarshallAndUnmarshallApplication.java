package lt.viko.eif.denis.kladijev.marshall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarshallAndUnmarshallApplication
{
	public static void main(String[] args)
	{
		SpringApplication.run(MarshallAndUnmarshallApplication.class, args);
	}
}
