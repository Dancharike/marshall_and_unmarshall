package lt.viko.eif.denis.kladijev.marshall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarshallAndUnmarshallApplicationTests {

	@Test
	void contextLoads() {
	}

}
